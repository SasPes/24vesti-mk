google.load("feeds", "1");

var page = location.search.split('page=')[1];

var i = 0;
var e = 8;

if (page == 2) {
    i = 8;
    e = 16;
}

if (page == 3) {
    i = 16;
    e = 24;
}

var newArticles = "";

function initialize() {
    var feed = new google.feeds.Feed("http://24vesti.mk/rss.xml");
    feed.setNumEntries(24);

    feed.load(function (result) {
        if (!result.error) {
            var container = document.getElementById("feed");
            var html = "";

            for (i; i < e; i++) {
                var entry = result.feed.entries[i];

                var dateP = new Date(Date.parse(entry.publishedDate));

                var dateDen = dateP.getDate() + "." + (dateP.getMonth() + 1) + "." + dateP.getFullYear();

                var hNula = false;
                if (dateP.getHours().toString().length == 1) {
                    hNula = true;
                }

                var mNula = false;
                if (dateP.getMinutes().toString().length == 1) {
                    mNula = true;
                }

                var dateVremeHours = dateP.getHours();
                var dateVremeMinutes = dateP.getMinutes();
                if (hNula) {
                    dateVremeHours = "0" + dateVremeHours;
                }
                if (mNula) {
                    dateVremeMinutes = "0" + dateVremeMinutes;
                }

                var dateVreme = dateVremeHours + ":" + dateVremeMinutes;

                var today = new Date();
                var todayDen = today.getDate() + "." + (today.getMonth() + 1) + "." + today.getFullYear();

                if (todayDen == dateDen) {
                    dateDen = "";
                } else {
                    dateDen = dateDen + " ";
                }

                dateP = dateDen + dateVreme;

                // img
                var content = entry.content;
                var regex = /src=\".+\.jpg\"/;
                var src = regex.exec(content);

                if (src == null) {
                    src = "src='imgs/icon24.jpg'";
                } else {
                    src = src[0];
                }

                if (newArticles > i) {
                    html = "<table><tr><td valign='top' width='24'><div style='width: 24px; height: 24px; overflow: hidden;'><img " + src + " style='height: 100%; padding:3px 0px 0px 0px;'/></div></td><td>" + "<h5>" + dateP + " " + "<a href='" + entry.link + "'>" + entry.title + "</a>" + " (" + entry.categories[0] + ") <img align='right' src='imgs/novo.png'></h5></td></tr></table>";
                } else {
                    html = "<table><tr><td valign='top' width='24'><div style='width: 24px; height: 24px; overflow: hidden;'><img " + src + " style='height: 100%; padding:3px 0px 0px 0px;'/></div></td><td>" + "<h5>" + dateP + " " + "<a href='" + entry.link + "'>" + entry.title + "</a>" + " (" + entry.categories[0] + ")</h5></td></tr></table>";
                }

                var div = document.createElement("div");
                div.innerHTML = html;
                container.appendChild(div);
            }

            var lastArtical = new Date(Date.parse(result.feed.entries[0].publishedDate));
            localStorage["lastPublishedDate"] = lastArtical;

            showWindowSize();
        }
    });
}
google.setOnLoadCallback(initialize);

var frm;
var frmAction;

function scriptonload() {
    if (page == null) {
        page = 1;
    }
    if (page == 1) {
        document.getElementById("1").style["border"] = "1px solid red";
    }
    if (page == 2) {
        document.getElementById("2").style["border"] = "1px solid red";
    }
    if (page == 3) {
        document.getElementById("3").style["border"] = "1px solid red";
    }

    frm = document.getElementById('search-form');
    frmAction = frm.action;
}

function clickHandler(e) {
    var search = document.getElementById('search').value;
    frm.action = frmAction + search;
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("baraj").addEventListener('click', clickHandler);
    scriptonload();
    weather();
    newArticles = localStorage["newArticles"];
    localStorage["newArticles"] = '';
    chrome.browserAction.setBadgeText({text: localStorage["newArticles"]});

    google.load("feeds", "1");
    initialize();
    google.setOnLoadCallback(initialize);
});

function weather() {
    var feed = new google.feeds.Feed("http://wxdata.weather.com/wxdata/weather/rss/local/MKXX0001?unit=m");
    feed.setNumEntries(1);

    feed.load(function (result) {
        if (!result.error) {
            var entry = result.feed.entries[0];

            // "Mostly Cloudy, and 12 &deg; C. For more details?"
            var contentSnippet = entry.contentSnippet;
            var condition = contentSnippet.split(" &deg; C.")[0];
            var start = condition.lastIndexOf(" ");
            var weather = condition.substring(start);
            weather = weather + " \u00b0" + "C";

            var content = entry.content;
            var end = content.indexOf(">");
            var src = content.substring(0, end + 1);

            src = src.replace('alt=""', 'style="vertical-align:middle;"');
            src = src.replace('.gif', '.png');
            
            // bad url: http://image.weather.com/web/common/wxicons/31/33.png?12122006
            // good url: http://fcgi.weather.com/web/common/wxicons/31/33.png?12122006
            src = src.replace('image.weather.com', 'fcgi.weather.com');

            var weatherP = document.getElementById('weather');
            weatherP.innerHTML = "<b>\u0421\u043A\u043E\u043F\u0458\u0435 " + src + weather + "</b>";
            //weatherP.innerHTML = src;

        }
    });
}

function showWindowSize() {
    var element = document.getElementById("page");
    //get width size of the body
    var clientHei = window.document.body.clientHeight;
    page.innerHTML = clientHei;
}
