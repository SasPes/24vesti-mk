google.load("feeds", "1");

function initialize() {
    var feed = new google.feeds.Feed("http://24vesti.mk/rss.xml");
    feed.setNumEntries(24);

    var newArticles = 0;
    var lastPublishedDate = new Date(Date.parse(localStorage["lastPublishedDate"]));
    if (typeof (lastPublishedDate) == 'undefined' || lastPublishedDate == null || lastPublishedDate == 'Invalid Date') {
        lastPublishedDate = new Date();
        localStorage["lastPublishedDate"] = lastPublishedDate;
    }

    feed.load(function(result) {
        if (!result.error) {
            for (var i = 0; i < 24; i++) {
                var entry = result.feed.entries[i];

                var publishedDate = new Date(Date.parse(entry.publishedDate));

                if (publishedDate.getTime() > lastPublishedDate.getTime()) {
                    newArticles = newArticles + 1;
                }
            }

            if (newArticles != 0) {
                localStorage["newArticles"] = newArticles;
            } else {
                localStorage["newArticles"] = "";
            }
            chrome.browserAction.setBadgeText({text: localStorage["newArticles"]});
        }
    });
}
google.setOnLoadCallback(initialize);

window.setInterval(function() {
    google.load("feeds", "1");
    initialize();
    google.setOnLoadCallback(initialize);
}, 1000 * 60 * 15); // 15 min
